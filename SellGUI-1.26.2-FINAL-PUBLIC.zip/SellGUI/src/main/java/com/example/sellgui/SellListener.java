package com.example.sellgui;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public final class SellListener implements Listener {
    private final SellGUI plugin;

    public SellListener(SellGUI plugin) {
        this.plugin = plugin;
    }

    private boolean isSellMenu(Inventory inv) {
        return inv.getHolder() instanceof SellMenu.SellHolder;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!isSellMenu(e.getView().getTopInventory())) return;
        if (!(e.getWhoClicked() instanceof Player player)) return;

        int raw = e.getRawSlot();

        if (raw == SellMenu.SELL_SLOT) {
            e.setCancelled(true);
            sell(player, e.getView().getTopInventory());
            return;
        }

        if (raw >= 0 && raw < e.getView().getTopInventory().getSize()) {
            if (raw >= 45) e.setCancelled(true);
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!isSellMenu(e.getInventory())) return;

        // Oyuncunun koyduğu itemleri kaybetmemesi için satış yapılmadan kapatınca geri verir.
        Player player = (Player) e.getPlayer();
        Inventory inv = e.getInventory();

        for (int slot = 0; slot < 45 && slot < inv.getSize(); slot++) {
            ItemStack item = inv.getItem(slot);
            if (item != null && item.getType() != Material.AIR) {
                java.util.HashMap<Integer, ItemStack> leftover = player.getInventory().addItem(item);
                leftover.values().forEach(left -> player.getWorld().dropItemNaturally(player.getLocation(), left));
                inv.setItem(slot, null);
            }
        }
    }

    private void sell(Player player, Inventory inv) {
        double total = 0;

        for (int slot = 0; slot < 45 && slot < inv.getSize(); slot++) {
            ItemStack item = inv.getItem(slot);
            if (item == null || item.getType() == Material.AIR) continue;

            String path = "prices." + item.getType().name();
            if (!plugin.getConfig().contains(path)) {
                player.sendMessage(color(plugin.getConfig().getString("messages.no-price")));
                return;
            }

            double price = plugin.getConfig().getDouble(path);
            total += price * item.getAmount();
        }

        if (total <= 0) {
            player.sendMessage(color(plugin.getConfig().getString("messages.no-items")));
            return;
        }

        for (int slot = 0; slot < 45 && slot < inv.getSize(); slot++) {
            inv.setItem(slot, null);
        }

        plugin.getEconomy().depositPlayer(player, total);
        String msg = plugin.getConfig().getString("messages.sold", "&aSatış tamamlandı! &e$%money%");
        player.sendMessage(color(msg.replace("%money%", String.format("%.2f", total))));
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text);
    }
}

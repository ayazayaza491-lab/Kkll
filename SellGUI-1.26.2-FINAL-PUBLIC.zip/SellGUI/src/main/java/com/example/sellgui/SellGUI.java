package com.example.sellgui;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public final class SellGUI extends JavaPlugin {
    private Economy economy;
    private SellCommand sellCommand;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        RegisteredServiceProvider<Economy> rsp =
                Bukkit.getServicesManager().getRegistration(Economy.class);

        if (rsp == null) {
            getLogger().severe("Vault ekonomi sağlayıcısı bulunamadı! EssentialsX Economy gibi bir ekonomi eklentisi kur.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        economy = rsp.getProvider();
        sellCommand = new SellCommand(this);

        getCommand("sell").setExecutor(sellCommand);
        getCommand("sell").setTabCompleter(sellCommand);
        getServer().getPluginManager().registerEvents(new SellListener(this), this);

        getLogger().info("SellGUI aktif!");
    }

    public Economy getEconomy() {
        return economy;
    }
}

package com.example.sellgui;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class SellMenu {
    public static final int SELL_SLOT = 49;
    private final SellGUI plugin;

    public SellMenu(SellGUI plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        int size = plugin.getConfig().getInt("menu-size", 54);
        if (size < 9 || size > 54 || size % 9 != 0) size = 54;

        String title = ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("menu-title", "&8Satış Menüsü"));

        Inventory inv = Bukkit.createInventory(new SellHolder(), size, title);

        ItemStack sell = new ItemStack(Material.EMERALD_BLOCK);
        ItemMeta meta = sell.getItemMeta();
        meta.setDisplayName(ChatColor.GREEN + "SAT");
        meta.setLore(java.util.List.of(ChatColor.GRAY + "Menüdeki itemleri sat."));
        sell.setItemMeta(meta);
        inv.setItem(SELL_SLOT, sell);

        player.openInventory(inv);
    }

    public static class SellHolder implements org.bukkit.inventory.InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }
}
